const express = require("express");
const router = express.Router();
const Emergency = require("../models/Emergency");
const verifyToken = require("../middleware/verifyToken");
const checkRole = require("../middleware/checkRole");
const { body, validationResult } = require("express-validator");

// 🔹 Test route
router.get("/test", (req, res) => {
  res.send("Emergency route is working ✅");
});

// 🔹 GET all emergencies (any logged-in user)
router.get("/", verifyToken, async (req, res) => {
  try {
    const emergencies = await Emergency.find();
    res.json(emergencies);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// 🔹 GET emergency by ID (any logged-in user)
router.get("/:id", verifyToken, async (req, res) => {
  try {
    const emergency = await Emergency.findById(req.params.id);
    if (!emergency) return res.status(404).json({ message: "Not found" });
    res.json(emergency);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// 🔹 CREATE emergency (any logged-in user)
router.post(
  "/",
  verifyToken,
  [
    body("title").notEmpty().withMessage("Title is required"),
    body("description").notEmpty().withMessage("Description is required"),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: errors.array()[0].msg });
    }

    try {
      const emergency = new Emergency({
        title: req.body.title,
        description: req.body.description,
        createdBy: req.user.id, // attach logged-in user id
      });
      const savedEmergency = await emergency.save();
      res.status(201).json({
        success: true,
        message: "Emergency created ✅",
        emergency: savedEmergency,
      });
    } catch (err) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// 🔹 UPDATE emergency by ID (any logged-in user can update their own)
router.put("/:id", verifyToken, async (req, res) => {
  try {
    const emergency = await Emergency.findById(req.params.id);
    if (!emergency) return res.status(404).json({ message: "Not found" });

    // Optional: allow only creator to update
    if (emergency.createdBy.toString() !== req.user.id) {
      return res.status(403).json({ message: "Forbidden: cannot update this emergency" });
    }

    emergency.title = req.body.title || emergency.title;
    emergency.description = req.body.description || emergency.description;

    const updatedEmergency = await emergency.save();
    res.json(updatedEmergency);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// 🔹 DELETE emergency by ID (only Admin)
router.delete("/:id", verifyToken,checkRole("admin"), async (req, res) => {
  try {
      const deletedEmergency = await Emergency.findByIdAndDelete(req.params.id);
    if (!deletedEmergency) return res.status(404).json({ message: "Not found" });
    res.json({ message: "Deleted successfully", deletedEmergency });
  } catch (err) {
    res.status(500).json({ message: err.message });
  
      }
});

module.exports = router;