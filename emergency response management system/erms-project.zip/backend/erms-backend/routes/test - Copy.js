require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User'); // path to your User model

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

async function checkUser() {
  const user = await User.findOne({ email: "admin@example.com" });
  console.log(user);
  process.exit(); // stops Node after printing
}

checkUser();