// script.js (Frontend)

const signupForm = document.getElementById("signupForm");
const loginForm = document.getElementById("loginForm");
const messageDiv = document.getElementById("message");
const dashboardDiv = document.getElementById("dashboard");

// ======= Signup =======
if (signupForm) {
  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value;

    if (!name || !email || !password) {
      showMessage("Please fill in all fields.", "error");
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });

      let data;
      try {
        data = await response.json();
      } catch {
        showMessage("Server did not return JSON. See console.", "error");
        const text = await response.text();
        console.error("Invalid JSON response:", text);
        return;
      }

      if (response.ok) {
        showMessage("Signup successful! You can now log in.", "success");
        signupForm.reset();
      } else {
        showMessage(data.message || "Signup failed. Try again.", "error");
      }
    } catch (err) {
      showMessage("Server error. Please try later.", "error");
      console.error(err);
    }
  });
}

// ======= Login =======
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    if (!email || !password) {
      showMessage("Please enter email and password.", "error");
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      let data;
      try {
        data = await response.json();
      } catch {
        showMessage("Server did not return JSON. See console.", "error");
        const text = await response.text();
        console.error("Invalid JSON response:", text);
        return;
      }

      if (response.ok) {
        localStorage.setItem("token", data.token);
        showMessage("Login successful!", "success");
        loginForm.reset();
        loadDashboard();
      } else {
        showMessage(data.message || "Invalid credentials.", "error");
      }
    } catch (err) {
      showMessage("Server error. Please try later.", "error");
      console.error(err);
    }
  });
}

// ======= Dashboard =======
async function loadDashboard() {
  const token = localStorage.getItem("token");
  if (!token) return;

  try {
    const response = await fetch("http://localhost:5000/api/emergency", {
      method: "GET",
      headers: { Authorization: Bearer` ${token}` },
    });

    let data;
    try {
      data = await response.json();
    } catch {
      showMessage("Server did not return JSON. See console.", "error");
      const text = await response.text();
      console.error("Invalid JSON response:", text);
      return;
    }

    if (response.ok) {
      dashboardDiv.style.display = "block";
      dashboardDiv.innerHTML = `<h2>Dashboard</h2>
                                <p>Total Emergencies: ${data.length}</p>
                                <button id="logoutBtn">Logout</button>`;
      document.getElementById("logoutBtn").addEventListener("click", logout);
    } else {
      showMessage("Session expired. Please log in again.", "error");
      localStorage.removeItem("token");
    }
  } catch (err) {
    showMessage("Server error. Please try later.", "error");
    console.error(err);
  }
}

// ======= Logout =======
function logout() {
  localStorage.removeItem("token");
  dashboardDiv.style.display = "none";
  showMessage("Logged out successfully.", "success");
}

// ======= Show Messages =======
function showMessage(msg, type) {
  messageDiv.style.display = "block";
  messageDiv.textContent = msg;
  messageDiv.style.color = type === "success" ? "green" : "red";
  setTimeout(() => (messageDiv.style.display = "none"), 3000);
}

// Load dashboard automatically if token exists
if (dashboardDiv) {
  loadDashboard();
}