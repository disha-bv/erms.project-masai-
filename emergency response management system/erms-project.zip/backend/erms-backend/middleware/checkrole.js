module.exports = function(allowedRoles) {
  return (req, res, next) => {
    const user = req.user; // req.user set by verifyToken
    if (!user || !allowedRoles.includes(user.role)) {
      return res.status(403).json({ success: false, message: "Forbidden: insufficient role" });
    }
    next();
  };
};