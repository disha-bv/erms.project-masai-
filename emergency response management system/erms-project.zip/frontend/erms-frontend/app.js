// ---------------- DOM ELEMENTS ----------------
const loginForm = document.getElementById("loginForm");
const tokenDisplay = document.getElementById("tokenDisplay");
const logoutBtn = document.getElementById("logoutBtn");
const showCreateBtn = document.getElementById("showCreateBtn");
const emergenciesBody = document.getElementById("emergenciesBody");
const alertContainer = document.getElementById("alertContainer");

// Modal elements
const modal = document.getElementById("modal");
const closeModalBtn = document.getElementById("closeModal");
const modalTitle = document.getElementById("modalTitle");
const modalForm = document.getElementById("modalForm");
const modalTitleInput = document.getElementById("modalTitleInput");
const modalDescriptionInput = document.getElementById("modalDescriptionInput");
const modalTitleError = document.getElementById("modalTitleError");
const modalDescError = document.getElementById("modalDescError");
const modalCancel = document.getElementById("modalCancel");

let userRole = null;
let editingEmergencyId = null;

// ---------------- UTILITY ----------------
function showAlert(message, type = "success") {
  alertContainer.innerHTML = <div class="alert ${type}">${message}</div>;
  setTimeout(() => alertContainer.innerHTML = "", 3000);
}

// ---------------- LOGIN ----------------
loginForm.addEventListener("submit", async e => {
  e.preventDefault();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  try {
    const res = await fetch("http://localhost:5000/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();

    if (!data.success) {
      tokenDisplay.textContent = "❌ Login failed: " + data.message;
      return;
    }

    tokenDisplay.textContent = Token: ${data.token};
    localStorage.setItem("token", data.token);
    userRole = data.role || null;

    // Show create button if allowed
    showCreateBtn.style.display = (userRole==="Admin" || userRole==="Operator") ? "inline-block" : "none";

    fetchEmergencies();
  } catch(err){
    tokenDisplay.textContent = "❌ Error: "+err.message;
  }
});

// ---------------- LOGOUT ----------------
logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("token");
  tokenDisplay.textContent = "Not logged in";
  emergenciesBody.innerHTML = "";
  showCreateBtn.style.display = "none";
  userRole = null;
  showAlert("Logged out successfully!", "success");
});

// ---------------- MODAL ----------------
showCreateBtn.addEventListener("click", () => {
  editingEmergencyId = null;
  modalTitle.textContent = "Create Emergency";
  modalForm.reset();
  modalTitleError.textContent = "";
  modalDescError.textContent = "";
  modal.style.display = "flex";
});
closeModalBtn.addEventListener("click", ()=> modal.style.display="none");
modalCancel.addEventListener("click", ()=> modal.style.display="none");
window.onclick = e => { if(e.target === modal) modal.style.display="none"; };

// ---------------- CREATE/UPDATE ----------------
modalForm.addEventListener("submit", async e => {
  e.preventDefault();
  modalTitleError.textContent = "";
  modalDescError.textContent = "";

  const title = modalTitleInput.value.trim();
  const description = modalDescriptionInput.value.trim();
  if(!title){ modalTitleError.textContent="Title required"; return;}
  if(!description){ modalDescError.textContent="Description required"; return;}

  const token = localStorage.getItem("token");
  if(!token){ showAlert("Login first!", "error"); return; }

  try{
    let url = "http://localhost:5000/api/emergency";
    let method = "POST";

    if(editingEmergencyId){
      url += /${editingEmergencyId};
      method = "PUT";
    }

    const res = await fetch(url, {
      method,
      headers:{ "Content-Type":"application/json", "Authorization":"Bearer "+token },
      body: JSON.stringify({ title, description })
    });

    const data = await res.json();
    if(data.success || data.message){
      showAlert(editingEmergencyId ? "Emergency updated!" : "Emergency created!", "success");
      modal.style.display = "none";
      fetchEmergencies();
    } else showAlert("Error: "+data.message, "error");
  }catch(err){
    showAlert("Error: "+err.message, "error");
  }
});

// ---------------- FETCH EMERGENCIES ----------------
async function fetchEmergencies(){
  const token = localStorage.getItem("token");
  if(!token) return;

  try{
    const res = await fetch("http://localhost:5000/api/emergency", {
      headers:{ "Authorization":"Bearer "+token }
    });
    const emergencies = await res.json();

    emergenciesBody.innerHTML = emergencies.map(e => {
      let actions = "";
      if(userRole === "Admin" || userRole === "Operator"){
        actions += `<button class="update" onclick="editEmergency('${e._id}','${e.title}','${e.description}')">Update</button> `;
      }
      if(userRole === "Admin"){
        actions += <button class="delete" onclick="deleteEmergency('${e._id}')">Delete</button>;
      }

      return `<tr>
        <td>${e.title}</td>
        <td>${e.description}</td>
        <td>${e.createdBy || "N/A"}</td>
        <td>${actions}</td>
      </tr>`;
    }).join("");

  } catch(err){
    emergenciesBody.innerHTML = <tr><td colspan="4">❌ Error: ${err.message}</td></tr>;
  }
}

// ---------------- EDIT EMERGENCY ----------------
function editEmergency(id, title, description){
  editingEmergencyId = id;
  modalTitle.textContent = "Update Emergency";
  modalTitleInput.value = title;
  modalDescriptionInput.value = description;
  modalTitleError.textContent = "";
  modalDescError.textContent = "";
  modal.style.display = "flex";
}

// ---------------- DELETE EMERGENCY ----------------
async function deleteEmergency(id){
  if(!confirm("Are you sure you want to delete this emergency?")) return;

  const token = localStorage.getItem("token");
  try{
    const res = await fetch(http://localhost:5000/api/emergency/${id}, {
      method:"DELETE",
      headers:{ "Authorization":"Bearer "+token }
    });
    const data = await res.json();
    showAlert(data.message || "Deleted successfully", "success");
    fetchEmergencies();
  }catch(err){
    showAlert("Error: "+err.message, "error");
  }
}