const signupDiv = document.getElementById('signupDiv');
const loginDiv = document.getElementById('loginDiv');
const dashboardDiv = document.getElementById('dashboardDiv');
const navSignup = document.getElementById('navSignup');
const navLogin = document.getElementById('navLogin');
const navDashboard = document.getElementById('navDashboard');
const logoutBtn = document.getElementById('logoutBtn');

const API_URL = 'http://localhost:5000/api'; // backend URL

// --- Navigation ---
navSignup.addEventListener('click', () => {
  signupDiv.classList.remove('hidden');
  loginDiv.classList.add('hidden');
  dashboardDiv.classList.add('hidden');
});
navLogin.addEventListener('click', () => {
  signupDiv.classList.add('hidden');
  loginDiv.classList.remove('hidden');
  dashboardDiv.classList.add('hidden');
});
navDashboard.addEventListener('click', () => {
  showDashboard();
});

// Logout
logoutBtn.addEventListener('click', () => {
  localStorage.removeItem('token');
  location.reload();
});

// --- Signup ---
document.getElementById('signupForm').addEventListener('submit', async e => {
  e.preventDefault();
  const email = document.getElementById('signupEmail').value;
  const password = document.getElementById('signupPassword').value;

  const res = await fetch(${API_URL}/auth/signup, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });

  let data;
  try {
    data = await res.json();
  } catch(err) {
    const text = await res.text();
    console.error('Invalid JSON response:', text);
    alert('Server did not return JSON. See console.');
    return;
  }

  document.getElementById('signupMessage').textContent = data.message || JSON.stringify(data);

  if(res.ok) {
    localStorage.setItem('token', data.token);
    showDashboard();
  }
});

// --- Login ---
document.getElementById('loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  const res = await fetch(${API_URL}/auth/login, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });

  let data;
  try {
    data = await res.json();
  } catch(err) {
    const text = await res.text();
    console.error('Invalid JSON response:', text);
    alert('Server did not return JSON. See console.');
    return;
  }

  document.getElementById('loginMessage').textContent = data.message || JSON.stringify(data);

  if(res.ok) {
    localStorage.setItem('token', data.token);
    showDashboard();
  }
});

// --- Dashboard ---
async function showDashboard() {
  signupDiv.classList.add('hidden');
  loginDiv.classList.add('hidden');
  dashboardDiv.classList.remove('hidden');
  navDashboard.classList.remove('hidden');
  logoutBtn.classList.remove('hidden');

  const token = localStorage.getItem('token');
  if(!token) { alert('Login required'); return; }

  // Fetch emergencies
  const res = await fetch(${API_URL}/emergency, {
    headers: { 'Authorization': Bearer ${token} }
  });

  let emergencies;
  try {
    emergencies = await res.json();
  } catch(err) {
    const text = await res.text();
    console.error('Invalid JSON response:', text);
    alert('Server did not return JSON. See console.');
    return;
  }

  // Stats
  const open = emergencies.filter(e => e.status === 'Open').length;
  const resolved = emergencies.filter(e => e.status === 'Resolved').length;
  const critical = emergencies.filter(e => e.status === 'Critical').length;
  document.getElementById('statsDiv').innerHTML = <strong>Open:</strong> ${open} &nbsp; <strong>Resolved:</strong> ${resolved} &nbsp; <strong>Critical:</strong> ${critical};

  // Table
  const table = document.getElementById('emergencyTable');
  table.innerHTML = '';
  emergencies.forEach(e => {
    const row = `<tr>
      <td>${e.title}</td>
      <td>${e.description}</td>
      <td><span class="badge ${e.status}">${e.status}</span></td>
    </tr>`;
    table.innerHTML += row;
  });
}

// --- Create Emergency ---
document.getElementById('createEmergencyForm').addEventListener('submit', async e => {
  e.preventDefault();
  const token = localStorage.getItem('token');
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const status = document.getElementById('status').value;

  const res = await fetch(${API_URL}/emergency, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': Bearer ${token}
    },
    body: JSON.stringify({ title, description, status })
  });

  let data;
  try {
    data = await res.json();
  } catch(err) {
    const text = await res.text();
    console.error('Invalid JSON response:', text);
    alert('Server did not return JSON. See console.');
    return;
  }

  if(res.ok) {
    document.getElementById('createEmergencyForm').reset();
    showDashboard();
  } else {
    alert(data.message || 'Error creating emergency');
  }
});

// --- Auto-login if token exists ---
if(localStorage.getItem('token')) showDashboard();