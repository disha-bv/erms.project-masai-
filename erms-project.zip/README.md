# Emergency Response Management System

Project ready to run.